module example.com/course/cli-practice

go 1.24.0
