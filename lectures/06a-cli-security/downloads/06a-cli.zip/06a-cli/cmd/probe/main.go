package main

import (
	"fmt"
	"os"
)

func main() {
	fmt.Printf("COUNT %d\n", len(os.Args)-1)
	for i, arg := range os.Args[1:] {
		fmt.Printf("%d=%q\n", i, arg)
	}
}
