package main

import (
	"fmt"
	"io"
	"os"
)

// run — готова межа задачі. Аргументи не містять імені програми.
// Додайте потрібні імпорти й замініть тіло згідно з умовою вправи.
func run(args []string, input io.Reader, output, errorOutput io.Writer) int {
	fmt.Fprintln(errorOutput, "NOT IMPLEMENTED")
	return 2
}

func main() {
	os.Exit(run(os.Args[1:], os.Stdin, os.Stdout, os.Stderr))
}
