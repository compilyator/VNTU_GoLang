package main

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
)

func main() {
	if len(os.Args) != 2 || len(os.Args[1]) > 80 {
		fmt.Fprintln(os.Stderr, "ARGUMENT ERROR")
		os.Exit(2)
	}
	self, err := os.Executable()
	if err != nil {
		fmt.Fprintln(os.Stderr, "RUN ERROR")
		os.Exit(1)
	}
	name := "child"
	if runtime.GOOS == "windows" {
		name += ".exe"
	}
	cmd := exec.Command(filepath.Join(filepath.Dir(self), name), "--", os.Args[1])
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	if err := cmd.Run(); err != nil {
		fmt.Fprintln(os.Stderr, "RUN ERROR")
		os.Exit(1)
	}
}
