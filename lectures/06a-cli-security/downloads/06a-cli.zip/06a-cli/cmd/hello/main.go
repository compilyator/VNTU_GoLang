package main

import (
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"strings"
	"time"
	"unicode/utf8"
)

func run() int {
	fs := flag.NewFlagSet("hello", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	name := fs.String("name", "student", "ім'я")
	count := fs.Int("count", 1, "кількість")
	upper := fs.Bool("upper", false, "верхній регістр")
	timeout := fs.Duration("timeout", 2*time.Second, "часовий ліміт")
	verbose := fs.Bool("verbose", false, "діагностика")
	if err := fs.Parse(os.Args[1:]); err != nil {
		if errors.Is(err, flag.ErrHelp) {
			fmt.Println("Usage: hello [-name text] [-count 1..3] [-upper] [-timeout 2s] [-verbose]")
			return 0
		}
		fmt.Fprintln(os.Stderr, "FORMAT ERROR")
		return 2
	}
	if fs.NArg() != 0 {
		fmt.Fprintln(os.Stderr, "ARGUMENT ERROR")
		return 2
	}
	if utf8.RuneCountInString(*name) < 1 || utf8.RuneCountInString(*name) > 20 || strings.ContainsAny(*name, "\r\n") || *count < 1 || *count > 3 || *timeout <= 0 || *timeout > 10*time.Second {
		fmt.Fprintln(os.Stderr, "RANGE ERROR")
		return 2
	}
	line := "Hello, " + *name + "!"
	if *upper {
		line = strings.ToUpper(line)
	}
	for i := 0; i < *count; i++ {
		fmt.Println(line)
	}
	if *verbose {
		fmt.Fprintln(os.Stderr, "TIMEOUT", *timeout)
	}
	return 0
}
func main() { os.Exit(run()) }
