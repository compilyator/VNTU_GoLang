package main

import (
	"fmt"
	"os"
)

func main() {
	if len(os.Args) != 3 || os.Args[1] != "--" || len(os.Args[2]) > 80 {
		fmt.Fprintln(os.Stderr, "ARGUMENT ERROR")
		os.Exit(2)
	}
	fmt.Printf("VALUE %q\n", os.Args[2])
}
