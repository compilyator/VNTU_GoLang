package main

import (
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
)

func run() int {
	fs := flag.NewFlagSet("reader", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	name := fs.String("file", "", "відносне ім'я")
	limit := fs.Int64("max-bytes", 32, "ліміт байтів")
	if err := fs.Parse(os.Args[1:]); err != nil {
		if errors.Is(err, flag.ErrHelp) {
			fmt.Println("Usage: reader -file relative-name [-max-bytes 1..1024]")
			return 0
		}
		fmt.Fprintln(os.Stderr, "FORMAT ERROR")
		return 2
	}
	if fs.NArg() != 0 {
		fmt.Fprintln(os.Stderr, "ARGUMENT ERROR")
		return 2
	}
	if *limit < 1 || *limit > 1024 {
		fmt.Fprintln(os.Stderr, "RANGE ERROR")
		return 2
	}
	bad := len(*name) == 0 || len(*name) > 200 || !filepath.IsLocal(*name) || strings.ContainsAny(*name, "\\:")
	for _, part := range strings.Split(*name, "/") {
		if part == ".." {
			bad = true
		}
	}
	if bad {
		fmt.Fprintln(os.Stderr, "PATH ERROR")
		return 2
	}
	root, err := os.OpenRoot("sandbox/allowed")
	if err != nil {
		fmt.Fprintln(os.Stderr, "OPEN ERROR")
		return 1
	}
	defer root.Close()
	file, err := root.Open(*name)
	if err != nil {
		fmt.Fprintln(os.Stderr, "OPEN ERROR")
		return 1
	}
	defer file.Close()
	info, err := file.Stat()
	if err != nil || !info.Mode().IsRegular() {
		fmt.Fprintln(os.Stderr, "OPEN ERROR")
		return 1
	}
	data, err := io.ReadAll(io.LimitReader(file, *limit+1))
	if err != nil {
		fmt.Fprintln(os.Stderr, "READ ERROR")
		return 1
	}
	if int64(len(data)) > *limit {
		fmt.Fprintln(os.Stderr, "SIZE ERROR")
		return 1
	}
	if _, err := os.Stdout.Write(data); err != nil {
		fmt.Fprintln(os.Stderr, "WRITE ERROR")
		return 1
	}
	return 0
}
func main() { os.Exit(run()) }
