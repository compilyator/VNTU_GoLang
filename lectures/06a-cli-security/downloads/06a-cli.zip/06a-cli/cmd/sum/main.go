package main

import (
	"fmt"
	"os"
	"strconv"
)

func main() {
	if len(os.Args) < 2 || len(os.Args) > 101 {
		fmt.Fprintln(os.Stderr, "ARGUMENT ERROR")
		os.Exit(2)
	}
	total := 0
	for _, arg := range os.Args[1:] {
		value, err := strconv.Atoi(arg)
		if err != nil {
			fmt.Fprintln(os.Stderr, "FORMAT ERROR")
			os.Exit(2)
		}
		if value < -1000 || value > 1000 {
			fmt.Fprintln(os.Stderr, "RANGE ERROR")
			os.Exit(2)
		}
		total += value
	}
	fmt.Println(total)
}
