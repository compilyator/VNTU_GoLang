module example.com/course/formats9a

go 1.24.0
