package testio

import (
	"bytes"
	"errors"
	"io"
)

var ErrRead = errors.New("навчальна помилка читання")
var ErrWrite = errors.New("навчальна помилка запису")
var ErrProduce = errors.New("навчальна помилка формування")

type FailReader struct {
	Data  []byte
	After int
	read  int
}

func (r *FailReader) Read(p []byte) (int, error) {
	if len(p) == 0 {
		return 0, nil
	}
	if r.read >= r.After {
		return 0, ErrRead
	}
	if len(r.Data) == 0 {
		return 0, io.EOF
	}
	size := r.After - r.read
	if size > len(p) {
		size = len(p)
	}
	n := copy(p[:size], r.Data)
	r.Data = r.Data[n:]
	r.read += n
	if r.read >= r.After {
		return n, ErrRead
	}
	return n, nil
}

type FailWriter struct {
	Limit  int
	Buffer bytes.Buffer
}

func (w *FailWriter) Write(p []byte) (int, error) {
	if len(p) == 0 {
		return 0, nil
	}
	left := w.Limit - w.Buffer.Len()
	if left < 0 {
		left = 0
	}
	if left < len(p) {
		n, _ := w.Buffer.Write(p[:left])
		return n, ErrWrite
	}
	return w.Buffer.Write(p)
}
