package brokenjsonl

import (
	"bufio"
	"bytes"
	"encoding/json"
	"errors"
	"example.com/course/formats9a/model"
	"fmt"
	"io"
	"unicode/utf8"
)

type Event = model.Event

func Read(r io.Reader) ([]Event, error) {
	data, e := io.ReadAll(io.LimitReader(r, 1025))
	if e != nil {
		return nil, e
	}
	if len(data) > 1024 || !utf8.Valid(data) {
		return nil, errors.New("неприйнятний вхід")
	}
	s := bufio.NewScanner(bytes.NewReader(data))
	s.Buffer(make([]byte, 128), 2048)
	result := make([]Event, 0)
	line := 0
	for s.Scan() {
		line++
		if len(bytes.TrimSpace(s.Bytes())) == 0 {
			continue
		}
		if len(s.Bytes()) > 128 || len(result) >= 10 {
			return nil, fmt.Errorf("рядок %d", line)
		}
		d := json.NewDecoder(bytes.NewReader(s.Bytes()))
		d.DisallowUnknownFields()
		var value *Event
		if e = d.Decode(&value); e != nil || value == nil {
			return nil, fmt.Errorf("рядок %d", line)
		}
		var extra any
		if d.Decode(&extra) != io.EOF {
			return nil, fmt.Errorf("рядок %d", line)
		}
		if value.Validate() != nil {
			return nil, fmt.Errorf("рядок %d", line)
		}
		result = append(result, *value)
	}
	if e = s.Err(); e != nil {
		return nil, e
	}
	return result, nil
}
