package brokencsv

import (
	"encoding/csv"
	"example.com/course/formats9a/model"
	"io"
	"strconv"
)

type Record = model.Record

func Write(dst io.Writer, values []Record) error {
	w := csv.NewWriter(dst)
	if e := w.Write([]string{"name", "score"}); e != nil {
		return e
	}
	for _, v := range values {
		if e := w.Write([]string{v.Name, strconv.Itoa(v.Score)}); e != nil {
			return e
		}
	}
	return w.Error()
}
