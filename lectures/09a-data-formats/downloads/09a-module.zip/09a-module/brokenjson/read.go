package brokenjson

import (
	"bytes"
	"encoding/json"
	"errors"
	"example.com/course/formats9a/model"
	"io"
	"unicode/utf8"
)

type Record = model.Record

func Read(r io.Reader) (Record, error) {
	var zero Record
	data, e := io.ReadAll(io.LimitReader(r, 1025))
	if e != nil {
		return zero, e
	}
	if len(data) > 1024 || !utf8.Valid(data) {
		return zero, errors.New("неприйнятний вхід")
	}
	d := json.NewDecoder(bytes.NewReader(data))
	d.DisallowUnknownFields()
	var value *Record
	if e = d.Decode(&value); e != nil {
		return zero, e
	}
	if value == nil {
		return zero, errors.New("очікується об’єкт")
	}
	if e = value.Validate(); e != nil {
		return zero, e
	}
	return *value, nil
}
