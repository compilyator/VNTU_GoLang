package model

import (
	"errors"
	"strings"
	"unicode/utf8"
)

type Record struct {
	Name  string `json:"name"`
	Score int    `json:"score"`
}
type Event struct {
	ID     int    `json:"id"`
	Status string `json:"status"`
}

func (r Record) Validate() error {
	n := utf8.RuneCountInString(r.Name)
	if n < 1 || n > 20 || strings.ContainsAny(r.Name, "\r\n") || r.Score < 0 || r.Score > 100 {
		return errors.New("неприпустимий запис")
	}
	return nil
}
func (e Event) Validate() error {
	if e.ID < 1 || e.ID > 1000 || (e.Status != "ok" && e.Status != "rejected") {
		return errors.New("неприпустима подія")
	}
	return nil
}
