# Набір F: JSON, JSONL та CSV

UTF-8 без BOM. Байти та відсутність кінцевого LF навмисні; не перезаписуйте входи редактором. Неправильні документи використовуються тільки у відповідних задачах. Дані вигадані. Значення =1+1 не виконуйте в електронних таблицях.

| Файл | Байти | SHA-256 |
|---|---:|---|
| `record.json` | 28 | `2225f66d45ae85b5b80bd324e26017d831d044a380c64870779b216835b2d5c4` |
| `bad-syntax.json` | 29 | `bfa530294fc49b9dc3814e2d983ed4e19502b38753171745478ae1ac6fc78186` |
| `wrong-type.json` | 30 | `7588923fef54a50e8829026fa3cf04548aeba7d934c7da85f12eddc148c3497b` |
| `unknown.json` | 41 | `d6095ac8cc12d913e94b73c4ebcc6294a62f14a1beea2dee9be0004a8406b1fe` |
| `two.json` | 57 | `da67a3d33246a1013772d8085f4e7715e8748c06dc75603895a7b58ea65492f2` |
| `trailing-space.json` | 31 | `7fa680f7489bbb3d8e49455f130801a7d66548d624cce44862a3c0409cc7d255` |
| `trailing-garbage.json` | 29 | `44e1d6a03d159d8699c4a0dcdf5a4b4954fd2f3c70ebedd62f81c96b6bfae650` |
| `nested-extra.json` | 68 | `aa157d424e8fa633dbe5fdff8d27c0e5b09de19a25db2ce9303673b7b61d7076` |
| `large-number.json` | 16 | `a1c367c29158357e62a3ff5d3e800fb7698a22396439dbc0a9d4929322afd35d` |
| `v1.json` | 27 | `f87f7f7aabb774bf86aa554b905514971a4becb398ddc53ce345569e695a6184` |
| `v2.json` | 28 | `3719dc600454cbfbf254386f5389bd4f09327f9314e7227614ac8383a64ef078` |
| `events-array.json` | 53 | `5f2ece96fc99e086ac4562784a5bdbad10be9f7d58c606c6c828e465c7f86d06` |
| `events.jsonl` | 52 | `1cc8894006c642e19ad76a186e403e0b14767e07accb6e35807ebda15b6f7969` |
| `blank-line.jsonl` | 53 | `0e54fa40dea53f06f4c12f74d1bc90806961412ca7e826d6de67969785a079a3` |
| `no-final.jsonl` | 51 | `1b01de0b29df8f75b10578aed82cb1075302eb1057343c2427d56bfe6d13e8b8` |
| `two-in-line.jsonl` | 52 | `333dd9a8bf3734260429d2d4c0df5415e3ac620e5acf4e7ae2bf10ce35aef59c` |
| `bad-line.jsonl` | 31 | `5f1e285c68967f09f6b5f87a046423216d98dd445a32f7c955f17585a7229bad` |
| `extra-line.jsonl` | 65 | `fd800ee4a12fcb0af0cb2a07178c4193398467633cc77082019f809078b0e2b3` |
| `empty.json` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `empty.jsonl` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `at-limit.json` | 2 | `44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a` |
| `over-limit.json` | 3 | `3d8e6a3f3561a8683abc16c3851110c4e607124c4c5a919cb7e78764882f37ad` |
| `formula-text.txt` | 17 | `8a64e60d3dc1763c1cc2060ff5409cdeacd53192bf9a9c1a968dd2b02f64f95a` |
| `people.csv` | 31 | `aa10c9fd2bd92ed35508e86f2d7139c3b0943db4eb6a0dbf27f06fee1659da0f` |
| `wrong-header.csv` | 21 | `23dd1270d91c2129095ce617aa256e8b41fde9806df94bf5b8f0c8832a24d323` |
| `extra-column.csv` | 27 | `1cc2751873647a04a4fb31efc9c134e0fc704a2a78b506d7adf4cbbd72a54698` |
| `quoted.csv` | 57 | `3a684ae70cf148daf542f0f7beb8a5834e9769b7d67a761e8e4b899986051cfb` |
| `quotes.csv` | 53 | `7a29581f33bbfa5f7fe798eeac96b0d22dc19e952f6e3b8ccb68a3ff44c3fde1` |
| `multiline.csv` | 48 | `533706e00133e4ca19db9d59400c81be0472d7360440cf58bd4d1dbe4f26bffa` |
| `semicolon.csv` | 21 | `ebca5017651e16c88985686fc4ae50dd2d5308a7fb706000168acadc1a047e81` |
| `bad-score.csv` | 22 | `ccfc87ea469a5c5a2a6391ba45b70238696cfd227a5ed4f0ed6187a215aabd1c` |
| `codes.csv` | 18 | `84ad49617789db345cb0f365bd6bc4e0ef92175742543a0c5e147a62f0eb216e` |
