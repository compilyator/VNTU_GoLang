package clone

func Clone[T any](values []T) []T { return values }
