package minimum

type Number interface{ ~int | ~int64 | ~float64 }

func Min[T Number](values []T) (T, bool) {
	var result T
	if len(values) == 0 {
		return result, false
	}
	for _, v := range values {
		if v < result {
			result = v
		}
	}
	return result, true
}
