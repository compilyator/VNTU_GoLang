module example.com/course/generics8b

go 1.24.0
