package legacy

func ContainsInts(values []int, target int) bool {
	for _, v := range values {
		if v == target {
			return true
		}
	}
	return false
}
func ContainsStrings(values []string, target string) bool {
	for _, v := range values {
		if v == target {
			return true
		}
	}
	return false
}
func CloneInts(values []int) []int {
	if values == nil {
		return nil
	}
	result := make([]int, len(values))
	copy(result, values)
	return result
}
func CloneStrings(values []string) []string {
	if values == nil {
		return nil
	}
	result := make([]string, len(values))
	copy(result, values)
	return result
}
func CountInts(values []int, target int) int {
	n := 0
	for _, v := range values {
		if v == target {
			n++
		}
	}
	return n
}
func CountStrings(values []string, target string) int {
	n := 0
	for _, v := range values {
		if v == target {
			n++
		}
	}
	return n
}
