package stack

type Stack[T any] struct{ values []T }

func (s *Stack[T]) Push(value T) {
	if s != nil {
		s.values = append(s.values, value)
	}
}
func (s *Stack[T]) Len() int {
	if s == nil {
		return 0
	}
	return len(s.values)
}
func (s *Stack[T]) Pop() (T, bool) {
	var zero T
	if s == nil || len(s.values) == 0 {
		return zero, false
	}
	last := len(s.values) - 1
	value := s.values[last]
	return value, true
}
