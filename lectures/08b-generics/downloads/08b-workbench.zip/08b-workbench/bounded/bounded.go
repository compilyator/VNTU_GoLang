package bounded

import "errors"

func Add[T comparable](set map[T]struct{}, value T, limit int) error {
	if set == nil || limit < 0 || limit > 100 {
		return errors.New("неприпустимі аргументи")
	}
	if len(set) >= limit {
		return errors.New("множина заповнена")
	}
	set[value] = struct{}{}
	return nil
}
