package unique

func Unique[T comparable](values []T) []T {
	result := make([]T, 0, len(values))
	for i, value := range values {
		found := false
		for j := i + 1; j < len(values); j++ {
			if values[j] == value {
				found = true
				break
			}
		}
		if !found {
			result = append(result, value)
		}
	}
	return result
}
