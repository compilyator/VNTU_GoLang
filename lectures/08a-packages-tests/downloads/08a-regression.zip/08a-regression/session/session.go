package session

import (
	"errors"
	"fmt"
	"strings"
	"unicode/utf8"
)

type Session struct{ name, token string }

func New(name, token string) (*Session, error) {
	n := utf8.RuneCountInString(name)
	if n < 1 || n > 20 || strings.ContainsAny(name, "\r\n") || len(token) < 1 || len(token) > 80 {
		return nil, errors.New("неприпустимі дані сеансу")
	}
	return &Session{name: name, token: token}, nil
}
func (s *Session) PublicSummary() string {
	if s == nil {
		return "NO SESSION"
	}
	return fmt.Sprintf("NAME %s TOKEN %s", s.name, s.token)
}
