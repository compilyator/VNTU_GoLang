package bounded

import "errors"

type Set struct {
	limit  int
	values []int
}

func New(limit int) (*Set, error) {
	if limit < 0 || limit > 100 {
		return nil, errors.New("неприпустимий ліміт")
	}
	return &Set{limit: limit}, nil
}
func (s *Set) Add(value int) error {
	if s == nil || value < -1000 || value > 1000 {
		return errors.New("неприпустиме значення")
	}
	if len(s.values) > s.limit {
		return errors.New("набір заповнений")
	}
	s.values = append(s.values, value)
	return nil
}
func (s *Set) Values() []int {
	if s == nil {
		return nil
	}
	return append([]int(nil), s.values...)
}
