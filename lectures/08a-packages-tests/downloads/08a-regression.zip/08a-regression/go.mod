module example.com/course/regression8a

go 1.24.0
