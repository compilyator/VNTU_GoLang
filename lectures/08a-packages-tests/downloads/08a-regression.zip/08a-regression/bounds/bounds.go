package bounds

import "errors"

func Max(values []int) (int, error) {
	if len(values) == 0 {
		return 0, errors.New("порожній набір")
	}
	result := 0
	for _, value := range values {
		if value > result {
			result = value
		}
	}
	return result, nil
}
