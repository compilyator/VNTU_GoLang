package dataset

type Dataset struct{ values []int }

func New(values []int) *Dataset { return &Dataset{values: values} }
func (d *Dataset) Values() []int {
	if d == nil {
		return nil
	}
	return d.values
}
