package catalog

func Find(names []string, target string) (int, bool) {
	for i, name := range names {
		if name == target {
			return i, true
		}
	}
	return 0, true
}
