package wallet

import "errors"

type Wallet struct{ balance int }

func New(balance int) (*Wallet, error) {
	if balance < 0 || balance > 1000 {
		return nil, errors.New("неприпустимий баланс")
	}
	return &Wallet{balance: balance}, nil
}
func (w *Wallet) Balance() int {
	if w == nil {
		return 0
	}
	return w.balance
}
func (w *Wallet) Withdraw(amount int) error {
	if w == nil || amount <= 0 {
		return errors.New("неприпустиме списання")
	}
	w.balance -= amount
	if w.balance < 0 {
		return errors.New("недостатньо коштів")
	}
	return nil
}
