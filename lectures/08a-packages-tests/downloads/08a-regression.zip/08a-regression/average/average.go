package average

func Mean(values []int) (float64, error) {
	if len(values) == 0 {
		return 0, nil
	}
	total := 0
	for _, value := range values {
		total += value
	}
	return float64(total) / float64(len(values)), nil
}
