module example.com/outside/consumer

go 1.24.0

require example.com/course/practice8a v0.0.0

replace example.com/course/practice8a => ..
