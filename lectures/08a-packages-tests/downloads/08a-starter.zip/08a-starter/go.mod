module example.com/course/practice8a

go 1.24.0
