# Набір K: контрольовані потоки та регресії

Go 1.24+, модуль уже створений, сторонніх залежностей немає. Початкова команда `go run ./cmd/demo` друкує READY. Функції для більшості задач студент реалізує у власному пакеті, імпорт починається з `example.com/course/files9/`.

**brokenread, brokenwrite, brokenpublish — навмисно несправні пакети для задач 98–100.** Це не готові розв’язки. Спершу напишіть тест за правильним контрактом задачі, відтворіть відмову, знайдіть дефект і виправте його. `publishcase.go.txt` — каркас задачі 93 поза звичайною збіркою; скопіюйте у свій пакет.

## API testio

Підміни потрібні, щоб відтворювати I/O без заповнення диска чи зміни дозволів ОС. Створюйте свіжий екземпляр для кожного тесту. Імпорт: `example.com/course/files9/testio`.

- `&ChunkReader{Data: []byte("ok"), Chunk: 4, FinalEOF: true}`: до Chunk байтів за виклик, EOF разом з останньою порцією за прапорця; без прапорця EOF наступним викликом. Chunk<=0 трактується як 1.
- `&FailReader{Data: []byte("abcdef"), After: 3}`: на межі After повертає останні дозволені байти разом з ErrRead; надалі 0,ErrRead. After невід’ємний, Data у вправах не коротша за нього.
- `&FailWriter{Limit: 2}`: приймає загалом до Limit байтів, при спробі перевищення повертає кількість прийнятих та ErrWrite. Прийняті дані доступні через Buffer.String(). Рівно Limit без спроби перевищення — успіх.
- `&ShortWriter{}`: навмисно порушує контракт Writer, приймаючи на один байт менше без error. Використовується тільки у задачі на виявлення короткого запису; дані у Buffer.
- `&CountReader{Reader: strings.NewReader("abc")}`: лічильники Calls і Bytes; не додає WriterTo, тому вимірює Read навіть при io.Copy.
- `&ReadCloser{Reader: r, CloseErr: ErrClose}`: CloseCalls і задана помилка Close; читання делегується r.
- `&Closer{CloseErr: ErrClose}`: тільки Close та CloseCalls.
- `&TrackedBuffer{}`: Write, Buffer, Closed, CloseCalls, CloseErr. Після Close запис відхиляється.
- `Tracker.Open(path)` відкриває справжній файл, рахує Active та Max; повернений io.ReadCloser треба закрити.
- `&RecorderOps{Fail: "Write"}`: без файлової системи журналює Create,Write,Close,Rename,Remove; Fail може бути порожнім, Write,Close,Rename. Методи відповідають інтерфейсу каркаса publishcase.go.txt. Один produce з одним Write робить очікуваний журнал однозначним. Remove успішний; помилка Close означає завершену спробу закриття, повторний Close не потрібний.

Помилки ErrRead, ErrWrite, ErrClose, ErrProduce, ErrRename порівнюйте через errors.Is. Вони синтетичні; не імітуйте їх зміною системних прав або заповненням диска.

PowerShell:
```powershell
go test ./... -count=1
go vet ./...
```

Bash:
```bash
go test ./... -count=1
go vet ./...
```

Спочатку тестів немає; `[no test files]` не підтверджує правильність. Після додавання регресійного тесту очікується FAIL до виправлення. Працюйте лише у власному навчальному каталозі, зі свіжими копіями F та t.TempDir().
