package brokenpublish

import (
	"io"
	"os"
)

func Publish(path string, produce func(io.Writer) error) error {
	f, e := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0600)
	if e != nil {
		return e
	}
	e = produce(f)
	closeErr := f.Close()
	if e != nil {
		return e
	}
	return closeErr
}
