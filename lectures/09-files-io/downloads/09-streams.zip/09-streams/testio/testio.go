package testio

import (
	"bytes"
	"errors"
	"io"
	"os"
)

var ErrRead = errors.New("навчальна помилка читання")
var ErrWrite = errors.New("навчальна помилка запису")
var ErrClose = errors.New("навчальна помилка закриття")
var ErrProduce = errors.New("навчальна помилка формування")
var ErrRename = errors.New("навчальна помилка перейменування")

type ChunkReader struct {
	Data     []byte
	Chunk    int
	FinalEOF bool
}

func (r *ChunkReader) Read(p []byte) (int, error) {
	if len(p) == 0 {
		return 0, nil
	}
	if len(r.Data) == 0 {
		return 0, io.EOF
	}
	size := r.Chunk
	if size < 1 {
		size = 1
	}
	if size > len(p) {
		size = len(p)
	}
	n := copy(p[:size], r.Data)
	r.Data = r.Data[n:]
	if len(r.Data) == 0 && r.FinalEOF {
		return n, io.EOF
	}
	return n, nil
}

type FailReader struct {
	Data  []byte
	After int
	read  int
}

func (r *FailReader) Read(p []byte) (int, error) {
	if len(p) == 0 {
		return 0, nil
	}
	if r.read >= r.After {
		return 0, ErrRead
	}
	if len(r.Data) == 0 {
		return 0, io.EOF
	}
	size := r.After - r.read
	if size > len(p) {
		size = len(p)
	}
	n := copy(p[:size], r.Data)
	r.Data = r.Data[n:]
	r.read += n
	if r.read >= r.After {
		return n, ErrRead
	}
	return n, nil
}

type FailWriter struct {
	Limit  int
	Buffer bytes.Buffer
}

func (w *FailWriter) Write(p []byte) (int, error) {
	if len(p) == 0 {
		return 0, nil
	}
	left := w.Limit - w.Buffer.Len()
	if left < 0 {
		left = 0
	}
	if left < len(p) {
		n, _ := w.Buffer.Write(p[:left])
		return n, ErrWrite
	}
	return w.Buffer.Write(p)
}

type ShortWriter struct{ Buffer bytes.Buffer }

func (w *ShortWriter) Write(p []byte) (int, error) {
	if len(p) == 0 {
		return 0, nil
	}
	return w.Buffer.Write(p[:len(p)-1])
}

type CountReader struct {
	Reader       io.Reader
	Calls, Bytes int
}

func (r *CountReader) Read(p []byte) (int, error) {
	r.Calls++
	n, e := r.Reader.Read(p)
	r.Bytes += n
	return n, e
}

type ReadCloser struct {
	Reader     io.Reader
	CloseErr   error
	CloseCalls int
}

func (r *ReadCloser) Read(p []byte) (int, error) { return r.Reader.Read(p) }
func (r *ReadCloser) Close() error               { r.CloseCalls++; return r.CloseErr }

type TrackedBuffer struct {
	Buffer     bytes.Buffer
	Closed     bool
	CloseErr   error
	CloseCalls int
}

func (w *TrackedBuffer) Write(p []byte) (int, error) {
	if w.Closed {
		return 0, ErrWrite
	}
	return w.Buffer.Write(p)
}
func (w *TrackedBuffer) Close() error { w.CloseCalls++; w.Closed = true; return w.CloseErr }

type Closer struct {
	CloseCalls int
	CloseErr   error
}

func (c *Closer) Close() error { c.CloseCalls++; return c.CloseErr }

type Tracker struct{ Active, Max int }
type trackedFile struct {
	*os.File
	owner  *Tracker
	closed bool
}

func (t *Tracker) Open(path string) (io.ReadCloser, error) {
	f, e := os.Open(path)
	if e != nil {
		return nil, e
	}
	t.Active++
	if t.Active > t.Max {
		t.Max = t.Active
	}
	return &trackedFile{File: f, owner: t}, nil
}
func (f *trackedFile) Close() error {
	if f.closed {
		return os.ErrClosed
	}
	f.closed = true
	f.owner.Active--
	return f.File.Close()
}

type RecorderOps struct {
	Fail   string
	Events []string
	Data   bytes.Buffer
}
type recordedFile struct{ ops *RecorderOps }

func (o *RecorderOps) Create() (io.WriteCloser, string, error) {
	o.Events = append(o.Events, "Create")
	return &recordedFile{ops: o}, "owned-temp", nil
}
func (f *recordedFile) Write(p []byte) (int, error) {
	o := f.ops
	o.Events = append(o.Events, "Write")
	if o.Fail == "Write" {
		return 0, ErrWrite
	}
	return o.Data.Write(p)
}
func (f *recordedFile) Close() error {
	o := f.ops
	o.Events = append(o.Events, "Close")
	if o.Fail == "Close" {
		return ErrClose
	}
	return nil
}
func (o *RecorderOps) Rename(from, to string) error {
	o.Events = append(o.Events, "Rename")
	if o.Fail == "Rename" {
		return ErrRename
	}
	return nil
}
func (o *RecorderOps) Remove(name string) error { o.Events = append(o.Events, "Remove"); return nil }
