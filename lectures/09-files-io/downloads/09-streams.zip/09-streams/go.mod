module example.com/course/files9

go 1.24.0
