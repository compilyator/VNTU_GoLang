package brokenread

import "io"

func Collect(r io.Reader) ([]byte, error) {
	var result []byte
	b := make([]byte, 4)
	for {
		n, e := r.Read(b)
		if e == io.EOF {
			return result, nil
		}
		if e != nil {
			return result, e
		}
		result = append(result, b[:n]...)
	}
}
