package brokenwrite

import (
	"bufio"
	"io"
)

func Emit(dst io.Writer, text string) error {
	w := bufio.NewWriter(dst)
	_, e := w.WriteString(text)
	return e
}
