# Набір F: точні байти

Не редагуйте входи редактором і не створюйте їх через текстовий конвеєр. UTF-8 без BOM; CRLF, LF, відсутність кінцевого LF та неправильні байти навмисні. Усі дані вигадані. `missing.txt` навмисно відсутній. Працюйте зі свіжою копією, створюйте вихід у власному out або t.TempDir().

| Файл | Байти | SHA-256 |
|---|---:|---|
| `empty.txt` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `blank.txt` | 1 | `01ba4719c80b6fe911b091a7c05124b64eeece964e09c058ef8f9805daca546b` |
| `ascii.txt` | 7 | `9262b6b5fa231eb962ff60bd89055f1bed32238340864a2974e02bbe3df78ce2` |
| `go.txt` | 3 | `c2fc355f2b52e01ea670dc8b27f1c8f3a268d68b4b399a0cf91544cb975792df` |
| `go-raw.txt` | 2 | `4cd0e21a9a0795a14ec9aa5f0e7d1abff0492565770e43eafdf1e3e8afed1f33` |
| `ok.txt` | 2 | `2689367b205c16ce32ed4200942b8b8b1e262dfc70d9bc9fbc77c49699a4f1df` |
| `uk.txt` | 22 | `e57f3caac9e9af2d509597a6ff6ae605016d768f0085765c508fd63a6d81a0e8` |
| `invalid-utf8.bin` | 2 | `eddf68639913a3cb8331cdfe7f87559e0beccf2c289c0d90ac4d89b3204004f8` |
| `binary.bin` | 6 | `97381d5c157e4dde189ba0e95afbfdd6cb231b6e9a99d0dac2e7570f0b24c3c3` |
| `lf.txt` | 4 | `911169ddaaf146aff539f58c26c489af3b892dff0fe283c1c264c65ae5aa59a2` |
| `crlf.txt` | 6 | `58055bdcc73787eb88c78d36f0b4939e9c5dc1c3ad17e25cc85a6833cf1a0cab` |
| `lines.txt` | 16 | `9895dbcdb07be62c9db69d39d1b7d6fce43f302f8e74707b70345bfe1c9a92d4` |
| `no-final.txt` | 3 | `7e18f737311b2dc3b2f269dd78396b0351f14fb66efa879f768cb23181883c78` |
| `words.txt` | 16 | `921c3e509fbfcea5b361acb2822295b3489d4d518a51f1a1aef24630357997f8` |
| `numbers.txt` | 8 | `8808b0fb41b4db70a625afd15b92e7f1ccb97de19044b0b5413de09e7948815b` |
| `bad-numbers.txt` | 7 | `faed625607b67281f9f65253894fe982da632515c47d7235dd7fcb3d96d2e054` |
| `long.txt` | 34 | `05efe94c2aaef826dc3ed1eba8afb2bd34ad2577719031deff25626c09185a7f` |
| `eight.txt` | 8 | `ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f` |
| `nine.txt` | 9 | `15e2b0d3c33891ebb0f1ef609ec419420c20e320ce94c65fbc8c3312448eb225` |
| `prefix.txt` | 17 | `c2a102eb197a6ba27dc2268ae7f3baa6ad8fdb7116cedc0555f6e737abdf051b` |
| `duplicates.txt` | 13 | `d10905d309665679b19fff96f8eeafba7e1d39120ae3cf719c77a59674fdf976` |
| `secret-invalid.bin` | 20 | `9f82427e6a5cefd9272ef85a9adfe233bcb59608542193395898acb78b426f9b` |
| `name with spaces.txt` | 6 | `9d39745403e5faf662463b32d613eedf45037d0180983ae8bc87f538cf0c9653` |
| `tree/a/one.txt` | 2 | `06f961b802bc46ee168555f066d28f4f0e9afdf3f88174c1ee6f9de004fc30a0` |
| `tree/b/two.txt` | 2 | `c0cde77fa8fef97d476c10aad3d2d54fcc2f336140d073651c2dcccf1e379fd6` |
| `sandbox/allowed/report..txt` | 2 | `2689367b205c16ce32ed4200942b8b8b1e262dfc70d9bc9fbc77c49699a4f1df` |
| `sandbox/allowed/sub/data.txt` | 7 | `7b2441693c861bf6969869d8b6f45f098bc8ef07b78ca043a1cb663159aabb10` |
| `sandbox/outside.txt` | 19 | `e27c8ae4f7d1c90b02a2fc448a941c7dda727d0af7690c9195604e28b6206a90` |
