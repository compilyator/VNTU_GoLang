package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"net/url"
	"os"
)

func main() {
	raw := flag.String("url", "", "URL")
	ref := flag.String("ref", "", "відносний URL")
	lang := flag.String("set-lang", "", "нове lang")
	allow := flag.String("allow", "", "дозволений origin")
	flag.Parse()
	u, err := url.Parse(*raw)
	if err != nil || u == nil || u.Host == "" || (u.Scheme != "http" && u.Scheme != "https") || flag.NArg() != 0 {
		fail("ERROR URL")
	}
	if *ref != "" {
		r, e := url.Parse(*ref)
		if e != nil {
			fail("ERROR URL")
		}
		u = u.ResolveReference(r)
	}
	q, e := url.ParseQuery(u.RawQuery)
	if e != nil {
		fail("ERROR URL")
	}
	if *lang != "" {
		q.Set("lang", *lang)
		u.RawQuery = q.Encode()
	}
	if *allow != "" {
		a, e := url.Parse(*allow)
		if e != nil || a == nil || u.User != nil || u.Scheme != a.Scheme || u.Hostname() != a.Hostname() || u.Port() != a.Port() {
			fail("ERROR ORIGIN")
		}
	}
	data, _ := json.Marshal(q)
	fmt.Printf("scheme: %s\nhost: %s\nhostname: %s\nport: %s\npath: %s\nquery: %s\nfragment: %s\nrequestURI: %s\n", u.Scheme, u.Host, u.Hostname(), u.Port(), u.Path, data, u.Fragment, u.RequestURI())
}
func fail(message string) { fmt.Fprintln(os.Stderr, message); os.Exit(2) }
