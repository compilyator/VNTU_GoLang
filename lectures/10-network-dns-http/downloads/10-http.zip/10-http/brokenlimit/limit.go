package brokenlimit

import (
	"errors"
	"io"
)

func Read(body io.ReadCloser, limit int64) ([]byte, error) {
	defer body.Close()
	if limit < 0 || limit > 4096 {
		return nil, errors.New("ліміт")
	}
	b, e := io.ReadAll(io.LimitReader(body, limit))
	if e != nil {
		return nil, e
	}
	if int64(len(b)) > limit {
		return nil, errors.New("завелике тіло")
	}
	return b, nil
}
