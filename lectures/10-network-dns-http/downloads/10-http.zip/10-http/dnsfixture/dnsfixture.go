package dnsfixture

import "errors"

var ErrNotFound = errors.New("ім'я відсутнє")
var ErrResolver = errors.New("resolver недоступний")

func Lookup(name string) ([]string, error) {
	switch name {
	case "multi.test":
		return []string{"192.0.2.20", "192.0.2.10"}, nil
	case "loopback.test":
		return []string{"127.0.0.1", "::1"}, nil
	case "failure.test":
		return nil, ErrResolver
	default:
		return nil, ErrNotFound
	}
}
