// Package lab запускає готовий go-httpbin у тимчасовому локальному сервері.
package lab

import (
	"example.com/course/http10/endpoints"
	"github.com/mccutchen/go-httpbin/v2/httpbin"
	"io"
	"log"
	"net/http"
	"net/http/httptest"
	"sync"
	"time"
)

type TestingT interface {
	Helper()
	Cleanup(func())
}
type Entry struct{ Method, Path string }
type Recorder struct {
	mu      sync.Mutex
	entries []Entry
	next    http.Handler
	Other   string
}

func (r *Recorder) Requests() []Entry {
	r.mu.Lock()
	defer r.mu.Unlock()
	return append([]Entry(nil), r.entries...)
}
func (r *Recorder) ServeHTTP(w http.ResponseWriter, q *http.Request) {
	r.mu.Lock()
	r.entries = append(r.entries, Entry{q.Method, q.URL.Path})
	r.mu.Unlock()
	switch q.URL.Path {
	case "/test/loop":
		w.Header().Set("Location", "/test/loop")
		w.WriteHeader(302)
	case "/test/cross":
		w.Header().Set("Location", r.Other+"/get")
		w.WriteHeader(302)
	default:
		r.next.ServeHTTP(w, q)
	}
}

type Site struct {
	BaseURL string
	Client  *http.Client
	Handler *Recorder
}

func (s *Site) URL(name string) string { return endpoints.URL(s.BaseURL, name) }
func Start(t TestingT, tls bool) *Site {
	t.Helper()
	r := &Recorder{next: httpbin.New()}
	srv := httptest.NewUnstartedServer(r)
	srv.Config.ErrorLog = log.New(io.Discard, "", 0)
	if tls {
		srv.StartTLS()
	} else {
		srv.Start()
	}
	c := srv.Client()
	c.Timeout = 3 * time.Second
	// Ці клієнти звертаються тільки до власного loopback-сервера.
	if tr, ok := c.Transport.(*http.Transport); ok {
		tr.Proxy = nil
	}
	t.Cleanup(func() { c.CloseIdleConnections(); srv.Close() })
	return &Site{srv.URL, c, r}
}
func StartPair(t TestingT, firstTLS bool) (*Site, *Site) {
	t.Helper()
	second := Start(t, false)
	first := Start(t, firstTLS)
	first.Handler.Other = second.BaseURL
	return first, second
}
