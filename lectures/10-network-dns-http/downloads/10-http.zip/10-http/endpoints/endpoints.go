package endpoints

import "strings"

const Public = "https://httpbingo.org"

// Paths містить справжні маршрути HTTPBingo, а не додаткові маршрути сервера.
var Paths = map[string]string{
	"echo":           "/anything",
	"html":           "/html",
	"empty":          "/status/204",
	"bytes8":         "/bytes/8?seed=1",
	"bytes9":         "/bytes/9?seed=1",
	"stream9":        "/stream-bytes/9?seed=1&chunk_size=3",
	"slow":           "/delay/2",
	"record":         "/base64/eyJuYW1lIjoi0J7Qu9GPIiwic2NvcmUiOjgwfQ==?content-type=application%2Fjson",
	"record-charset": "/base64/eyJuYW1lIjoi0J7Qu9GPIiwic2NvcmUiOjgwfQ==?content-type=application%2Fjson%3B+charset%3Dutf-8",
	"text":           "/base64/b2sK?content-type=text%2Fplain",
	"bad-json":       "/base64/e2Jyb2tlbg==?content-type=application%2Fjson",
	"bad-record":     "/base64/eyJuYW1lIjoi0J7Qu9GPIiwic2NvcmUiOjEwMX0=?content-type=application%2Fjson",
	"two-json":       "/base64/eyJuYW1lIjoi0J7Qu9GPIiwic2NvcmUiOjgwfXsibmFtZSI6ItCe0LvRjyIsInNjb3JlIjo4MH0=?content-type=application%2Fjson",
	"unknown-json":   "/base64/eyJuYW1lIjoi0J7Qu9GPIiwic2NvcmUiOjgwLCJleHRyYSI6MX0=?content-type=application%2Fjson",
	"records":        "/base64/W3sibmFtZSI6ItCe0LvRjyIsInNjb3JlIjo4MH0seyJuYW1lIjoi0IbRgNCwIiwic2NvcmUiOjkwfV0=?content-type=application%2Fjson",
	"sample":         "/base64/eyJhcmdzIjp7InRvcGljIjoiaHR0cCJ9fQ==?content-type=application%2Fjson",
}

// URL повертає порожній рядок для невідомої назви.
func URL(base, name string) string {
	path, ok := Paths[name]
	if !ok {
		return ""
	}
	return strings.TrimRight(base, "/") + path
}
