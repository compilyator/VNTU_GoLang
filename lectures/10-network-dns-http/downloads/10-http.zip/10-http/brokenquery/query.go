package brokenquery

import (
	"errors"
	"net/url"
)

func Build(base, message, lang string) (string, error) {
	if len(message) > 80 || (lang != "uk" && lang != "en") {
		return "", errors.New("аргументи")
	}
	u, e := url.Parse(base)
	if e != nil {
		return "", e
	}
	if u.Host == "" || u.User != nil || (u.Scheme != "https" && u.Scheme != "http") {
		return "", errors.New("URL")
	}
	u.RawQuery = "message=" + message + "&lang=" + lang
	return u.String(), nil
}
