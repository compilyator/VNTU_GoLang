package testio

import (
	"errors"
	"fmt"
	"io"
	"net/http"
)

var ErrTransport = errors.New("навчальна помилка транспорту")
var ErrRead = errors.New("навчальна помилка читання")
var ErrWrite = errors.New("навчальна помилка запису")

type TrackBody struct {
	Data       []byte
	FinalEOF   bool
	Fail       bool
	FailAfter  int
	ReadBytes  int
	Closed     bool
	CloseCalls int
}

func (b *TrackBody) Read(p []byte) (int, error) {
	if b.Closed {
		return 0, errors.New("тіло закрито")
	}
	if len(p) == 0 {
		return 0, nil
	}
	if b.Fail && b.ReadBytes >= b.FailAfter {
		return 0, ErrRead
	}
	if b.ReadBytes >= len(b.Data) {
		return 0, io.EOF
	}
	end := len(b.Data)
	if b.Fail && b.FailAfter < end {
		end = b.FailAfter
	}
	n := copy(p, b.Data[b.ReadBytes:end])
	b.ReadBytes += n
	if b.Fail && b.ReadBytes >= b.FailAfter {
		return n, ErrRead
	}
	if b.FinalEOF && b.ReadBytes == len(b.Data) {
		return n, io.EOF
	}
	return n, nil
}
func (b *TrackBody) Close() error { b.Closed = true; b.CloseCalls++; return nil }

type Stub struct {
	Status int
	Header http.Header
	Body   io.ReadCloser
	Err    error
	Calls  int
}

func (s *Stub) RoundTrip(r *http.Request) (*http.Response, error) {
	s.Calls++
	if s.Err != nil {
		return nil, s.Err
	}
	body := s.Body
	if body == nil {
		body = http.NoBody
	}
	return &http.Response{StatusCode: s.Status, Status: fmt.Sprintf("%d %s", s.Status, http.StatusText(s.Status)), Header: s.Header.Clone(), Body: body, ContentLength: -1, Request: r}, nil
}
