package brokenredirect

import (
	"errors"
	"net/http"
	"net/url"
)

func Check(allowed string, max int) func(*http.Request, []*http.Request) error {
	a, e := url.Parse(allowed)
	return func(r *http.Request, via []*http.Request) error {
		if e != nil || a == nil || a.Host == "" || max < 0 || max > 5 {
			return errors.New("конфігурація")
		}
		if r.URL.User != nil {
			return errors.New("userinfo")
		}
		if r.URL.Scheme != a.Scheme || r.URL.Hostname() != a.Hostname() {
			return errors.New("origin")
		}
		if len(via) > max {
			return errors.New("ліміт redirect")
		}
		return nil
	}
}
