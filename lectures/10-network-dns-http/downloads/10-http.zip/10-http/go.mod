module example.com/course/http10

go 1.25.0

require github.com/mccutchen/go-httpbin/v2 v2.25.0
