#!/usr/bin/env bash
set -eu
name=${1:-git-lab}
case "$name" in ''|*[!A-Za-z0-9_-]*) printf 'Use letters, digits, _ or - for the directory name.\n' >&2; exit 2;; esac
if [ "$#" -gt 1 ]; then printf 'Usage: bash setup.sh [name]\n' >&2; exit 2; fi
target="$PWD/$name"
if [ -e "$target" ] || [ -L "$target" ]; then printf 'Directory exists; choose a new name. No data changed.\n' >&2; exit 2; fi
command -v git >/dev/null
g() {
    if message=$(git "$@" 2>&1); then return 0; fi
    printf '%s\n' "$message" >&2
    return 1
}
configure() {
    g -C "$1" config user.name 'Demo Student'
    g -C "$1" config user.email student@example.invalid
    g -C "$1" config commit.gpgsign false
    g -C "$1" config core.autocrlf false
    g -C "$1" config core.fsmonitor false
    g -C "$1" config core.hooksPath .git/course-hooks
}
mkdir -- "$target"
basic="$target/basic"
g -c init.templateDir= init -b main "$basic"
configure "$basic"
printf '# Demo\n' > "$basic/README.md"
printf '10\n' > "$basic/value.txt"
printf 'alpha\n' > "$basic/notes.txt"
printf 'build/\n*.tmp\n.env\n' > "$basic/.gitignore"
g -C "$basic" add .
g -C "$basic" commit -m 'docs: add initial files'
g -C "$basic" switch -c feature
printf 'feature\n' > "$basic/feature.txt"
g -C "$basic" add feature.txt
g -C "$basic" commit -m 'feat: add feature marker'
g -C "$basic" switch main
conflict="$target/conflict"
g -c init.templateDir= init -b main "$conflict"
configure "$conflict"
printf 'color=blue\n' > "$conflict/message.txt"
g -C "$conflict" add .
g -C "$conflict" commit -m 'docs: add base color'
g -C "$conflict" switch -c update
printf 'color=green\n' > "$conflict/message.txt"
g -C "$conflict" commit -am 'docs: set green color'
g -C "$conflict" switch main
printf 'color=red\n' > "$conflict/message.txt"
g -C "$conflict" commit -am 'docs: set red color'
remote="$target/remote.git"
g -c init.templateDir= -c core.autocrlf=false -c core.fsmonitor=false -c core.hooksPath=.git/course-hooks clone --bare "$basic" "$remote"
for copy in alice bob; do
    g -c init.templateDir= -c core.autocrlf=false -c core.fsmonitor=false -c core.hooksPath=.git/course-hooks clone "$remote" "$target/$copy"
    configure "$target/$copy"
done
printf 'READY %s\n' "$name"
