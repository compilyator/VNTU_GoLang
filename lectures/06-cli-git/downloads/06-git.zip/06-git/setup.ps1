param([string]$Name = 'git-lab')
$ErrorActionPreference = 'Stop'
if ($Name -notmatch '^[A-Za-z0-9_-]+$') { throw 'Використайте просту назву каталогу: літери, цифри, _ або -.' }
$target = Join-Path (Get-Location).Path $Name
if (Test-Path -LiteralPath $target) { throw 'Каталог уже існує. Оберіть нову назву; наявні дані не змінено.' }
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw 'Потрібен Git.' }
function Invoke-GitChecked {
    param([string[]]$Arguments)
    $message = & git @Arguments 2>&1
    if ($LASTEXITCODE -ne 0) { throw ('Не вдалося виконати Git: ' + ($Arguments -join ' ') + "`n" + ($message -join "`n")) }
}
function Set-DemoConfig {
    param([string]$Repository)
    Invoke-GitChecked @('-C', $Repository, 'config', 'user.name', 'Demo Student')
    Invoke-GitChecked @('-C', $Repository, 'config', 'user.email', 'student@example.invalid')
    Invoke-GitChecked @('-C', $Repository, 'config', 'commit.gpgsign', 'false')
    Invoke-GitChecked @('-C', $Repository, 'config', 'core.autocrlf', 'false')
    Invoke-GitChecked @('-C', $Repository, 'config', 'core.fsmonitor', 'false')
    Invoke-GitChecked @('-C', $Repository, 'config', 'core.hooksPath', '.git/course-hooks')
}
function Write-DemoFile {
    param([string]$FilePath, [string]$Content)
    [IO.File]::WriteAllText($FilePath, $Content, [Text.UTF8Encoding]::new($false))
}
New-Item -ItemType Directory -Path $target | Out-Null
$basic = Join-Path $target 'basic'
Invoke-GitChecked @('-c', 'init.templateDir=', 'init', '-b', 'main', $basic)
Set-DemoConfig $basic
Write-DemoFile (Join-Path $basic 'README.md') "# Demo`n"
Write-DemoFile (Join-Path $basic 'value.txt') "10`n"
Write-DemoFile (Join-Path $basic 'notes.txt') "alpha`n"
Write-DemoFile (Join-Path $basic '.gitignore') "build/`n*.tmp`n.env`n"
Invoke-GitChecked @('-C', $basic, 'add', '.')
Invoke-GitChecked @('-C', $basic, 'commit', '-m', 'docs: add initial files')
Invoke-GitChecked @('-C', $basic, 'switch', '-c', 'feature')
Write-DemoFile (Join-Path $basic 'feature.txt') "feature`n"
Invoke-GitChecked @('-C', $basic, 'add', 'feature.txt')
Invoke-GitChecked @('-C', $basic, 'commit', '-m', 'feat: add feature marker')
Invoke-GitChecked @('-C', $basic, 'switch', 'main')
$conflict = Join-Path $target 'conflict'
Invoke-GitChecked @('-c', 'init.templateDir=', 'init', '-b', 'main', $conflict)
Set-DemoConfig $conflict
Write-DemoFile (Join-Path $conflict 'message.txt') "color=blue`n"
Invoke-GitChecked @('-C', $conflict, 'add', '.')
Invoke-GitChecked @('-C', $conflict, 'commit', '-m', 'docs: add base color')
Invoke-GitChecked @('-C', $conflict, 'switch', '-c', 'update')
Write-DemoFile (Join-Path $conflict 'message.txt') "color=green`n"
Invoke-GitChecked @('-C', $conflict, 'commit', '-am', 'docs: set green color')
Invoke-GitChecked @('-C', $conflict, 'switch', 'main')
Write-DemoFile (Join-Path $conflict 'message.txt') "color=red`n"
Invoke-GitChecked @('-C', $conflict, 'commit', '-am', 'docs: set red color')
$remote = Join-Path $target 'remote.git'
Invoke-GitChecked @('-c', 'init.templateDir=', '-c', 'core.autocrlf=false', '-c', 'core.fsmonitor=false', '-c', 'core.hooksPath=.git/course-hooks', 'clone', '--bare', $basic, $remote)
foreach ($copy in @('alice', 'bob')) {
    $repository = Join-Path $target $copy
    Invoke-GitChecked @('-c', 'init.templateDir=', '-c', 'core.autocrlf=false', '-c', 'core.fsmonitor=false', '-c', 'core.hooksPath=.git/course-hooks', 'clone', $remote, $repository)
    Set-DemoConfig $repository
}
Write-Output "READY $Name"
