#!/usr/bin/env bash
printf "HELLO LINUX\n"
