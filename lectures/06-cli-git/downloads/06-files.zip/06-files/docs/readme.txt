CLI practice
Use only this directory.
