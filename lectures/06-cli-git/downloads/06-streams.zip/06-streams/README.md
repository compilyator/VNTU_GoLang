# Потоки

У каталозі набору зберіть програму: PowerShell — `go build -buildvcs=false -o stream.exe .`, Bash — `go build -buildvcs=false -o stream .`. Потрібен Go 1.24 або новіший. Програма читає до EOF не більше 100 цілих від -1000 до 1000. Успіх: `COUNT n SUM s` у stdout, `DONE` у stderr, код 0. Помилки у stderr, порожній stdout, код 2. Різні способи перенаправлення наведено в задачнику.
