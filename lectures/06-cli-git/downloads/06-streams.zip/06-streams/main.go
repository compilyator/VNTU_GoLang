package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
)

func main() {
	if len(os.Args) != 1 {
		fmt.Fprintln(os.Stderr, "ARGUMENT ERROR")
		os.Exit(2)
	}
	scanner := bufio.NewScanner(os.Stdin)
	scanner.Split(bufio.ScanWords)
	count, sum := 0, 0
	for scanner.Scan() {
		if count == 100 {
			fmt.Fprintln(os.Stderr, "LIMIT ERROR")
			os.Exit(2)
		}
		value, err := strconv.Atoi(scanner.Text())
		if err != nil {
			fmt.Fprintln(os.Stderr, "INPUT ERROR")
			os.Exit(2)
		}
		if value < -1000 || value > 1000 {
			fmt.Fprintln(os.Stderr, "RANGE ERROR")
			os.Exit(2)
		}
		count++
		sum += value
	}
	if scanner.Err() != nil {
		fmt.Fprintln(os.Stderr, "INPUT ERROR")
		os.Exit(2)
	}
	fmt.Printf("COUNT %d SUM %d\n", count, sum)
	fmt.Fprintln(os.Stderr, "DONE")
}
