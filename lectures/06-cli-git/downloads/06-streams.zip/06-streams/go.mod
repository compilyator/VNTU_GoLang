module example.com/course/stream-practice

go 1.24.0
